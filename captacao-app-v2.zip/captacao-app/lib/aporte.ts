import { supabaseAdmin } from "@/lib/supabase/admin";
import {
  taxaEfetivaAnual, saldoBrutoAtualizado, contarDiasUteis,
  posicaoCotasFIDC, type ParametrosRemuneracao, type RegimeTributario,
} from "@/lib/funding-engine";

export interface AporteAtual {
  aporteId: string; empresa: string; investidor: string;
  valorAportado: number; dataAporte: string; saldoBruto: number;
  rendimento: number; regime: RegimeTributario; diasCorridos: number; taxaEf: number;
}

async function cdiVigente(): Promise<number> {
  const { data } = await supabaseAdmin.from("cdi_historico").select("taxa_anual").order("data_referencia", { ascending: false }).limit(1).maybeSingle();
  return data ? Number(data.taxa_anual) : 0;
}
async function valorCotaAtual(empresaId: string): Promise<number | null> {
  const { data } = await supabaseAdmin.from("cotas_valor_historico").select("valor_cota").eq("empresa_id", empresaId).order("data_referencia", { ascending: false }).limit(1).maybeSingle();
  return data ? Number(data.valor_cota) : null;
}
async function jaResgatado(aporteId: string): Promise<number> {
  const { data } = await supabaseAdmin.from("resgates").select("valor_bruto").eq("aporte_id", aporteId);
  return (data ?? []).reduce((s, r) => s + Number(r.valor_bruto), 0);
}

async function calcular(a: any, cdi: number): Promise<AporteAtual> {
  const params: ParametrosRemuneracao = {
    tipo: a.tipo_remuneracao, taxaValor: a.taxa_valor ?? undefined,
    periodo: a.periodo_taxa ?? undefined, percentualCdi: a.percentual_cdi ?? undefined,
  };
  const taxaEf = taxaEfetivaAnual(params, cdi);
  const dataAporte = new Date(a.data_aporte);
  const hoje = new Date();
  const diasUteis = contarDiasUteis(dataAporte, hoje);
  const diasCorridos = Math.floor((hoje.getTime() - dataAporte.getTime()) / 86400000);
  const cotaAtual = a.instrumentos_financeiros?.baseado_em_cotas ? await valorCotaAtual(a.empresa_id) : null;
  let saldoBruto: number; let rendimento: number;
  if (cotaAtual && a.quantidade_cotas && a.valor_cota_aporte) {
    const p = posicaoCotasFIDC(a.quantidade_cotas, a.valor_cota_aporte, cotaAtual);
    saldoBruto = p.patrimonioBruto; rendimento = p.rendimentoBruto;
  } else {
    saldoBruto = saldoBrutoAtualizado(a.valor_aporte, taxaEf, diasUteis);
    rendimento = saldoBruto - a.valor_aporte;
  }
  saldoBruto -= await jaResgatado(a.id); if (saldoBruto < 0) saldoBruto = 0;
  if (rendimento < 0) rendimento = 0;
  const regime: RegimeTributario =
    a.instrumentos_financeiros?.isento_ir || a.empresas?.tipo === "contratos" ? "isento" : (a.empresas?.regime_tributario as RegimeTributario);
  return {
    aporteId: a.id, empresa: a.empresas?.nome, investidor: a.investidores?.nome_razao_social,
    valorAportado: a.valor_aporte, dataAporte: a.data_aporte, saldoBruto, rendimento, regime, diasCorridos, taxaEf,
  };
}

export async function computeAportesAtivos(): Promise<AporteAtual[]> {
  const cdi = await cdiVigente();
  const { data } = await supabaseAdmin.from("aportes")
    .select(`*, empresas!inner(nome, tipo, regime_tributario), investidores!inner(nome_razao_social), instrumentos_financeiros!inner(baseado_em_cotas, isento_ir)`)
    .eq("status", "ativo").order("data_aporte", { ascending: false });
  const out: AporteAtual[] = [];
  for (const a of data ?? []) out.push(await calcular(a, cdi));
  return out;
}

export async function computeAporteAtual(aporteId: string): Promise<AporteAtual | null> {
  const cdi = await cdiVigente();
  const { data } = await supabaseAdmin.from("aportes")
    .select(`*, empresas!inner(nome, tipo, regime_tributario), investidores!inner(nome_razao_social), instrumentos_financeiros!inner(baseado_em_cotas, isento_ir)`)
    .eq("id", aporteId).maybeSingle();
  if (!data) return null;
  return calcular(data, cdi);
}
