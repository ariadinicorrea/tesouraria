import { computeAportesAtivos } from "@/lib/aporte";
import { supabaseAdmin } from "@/lib/supabase/admin";
import { NovoResgate } from "@/components/novo-resgate";
import { Card } from "@/components/ui";
import { fmtBRL, fmtPct, fmtData } from "@/lib/format";

export const dynamic = "force-dynamic";

export default async function ResgatesPage() {
  const aportes = await computeAportesAtivos();
  const { data: historico } = await supabaseAdmin.from("resgates")
    .select("*, aportes(empresas(nome), investidores(nome_razao_social))")
    .order("data_resgate", { ascending: false }).limit(30);

  return (
    <div className="p-8">
      <header><div className="eyebrow">Operações</div><h1 className="mt-1 text-xl font-semibold tracking-tight">Resgates</h1></header>
      <div className="mt-6"><NovoResgate aportes={aportes} /></div>

      <Card className="mt-6">
        <div className="border-b px-5 py-3 eyebrow">Histórico de resgates</div>
        <table className="w-full text-sm">
          <thead><tr className="text-left text-xs text-muted">
            <th className="px-5 py-2 font-medium">Data</th>
            <th className="px-5 py-2 font-medium">Investidor</th>
            <th className="px-5 py-2 font-medium">Empresa</th>
            <th className="px-5 py-2 font-medium">Tipo</th>
            <th className="px-5 py-2 text-right font-medium">Bruto</th>
            <th className="px-5 py-2 text-right font-medium">IR</th>
            <th className="px-5 py-2 text-right font-medium">Líquido</th>
          </tr></thead>
          <tbody>
            {(historico ?? []).map((r: any) => (
              <tr key={r.id} className="border-t">
                <td className="num px-5 py-3">{fmtData(r.data_resgate)}</td>
                <td className="px-5 py-3">{r.aportes?.investidores?.nome_razao_social ?? "—"}</td>
                <td className="px-5 py-3 text-muted">{r.aportes?.empresas?.nome ?? "—"}</td>
                <td className="px-5 py-3 text-muted">{r.tipo_resgate}</td>
                <td className="num px-5 py-3 text-right">{fmtBRL(r.valor_bruto)}</td>
                <td className="num px-5 py-3 text-right text-warn">{fmtBRL(r.ir_retido)} <span className="text-xs text-muted">({fmtPct(r.aliquota_ir, 1)})</span></td>
                <td className="num px-5 py-3 text-right font-semibold">{fmtBRL(r.valor_liquido)}</td>
              </tr>
            ))}
            {(!historico || historico.length === 0) && (<tr><td colSpan={7} className="px-5 py-6 text-center text-muted">Nenhum resgate ainda.</td></tr>)}
          </tbody>
        </table>
      </Card>
    </div>
  );
}
