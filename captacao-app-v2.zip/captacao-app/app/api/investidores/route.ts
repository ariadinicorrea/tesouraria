import { NextResponse } from "next/server";
import { supabaseAdmin } from "@/lib/supabase/admin";

export const dynamic = "force-dynamic";

export async function GET() {
  const { data, error } = await supabaseAdmin
    .from("investidores")
    .select("*")
    .order("created_at", { ascending: false });
  if (error) return NextResponse.json({ ok: false, erro: error.message }, { status: 500 });
  return NextResponse.json({ ok: true, investidores: data });
}

export async function POST(req: Request) {
  const body = await req.json();
  const { error, data } = await supabaseAdmin
    .from("investidores")
    .insert({
      nome_razao_social: body.nome_razao_social,
      documento: String(body.documento ?? "").replace(/\D/g, ""),
      tipo_pessoa: body.tipo_pessoa,
      email: body.email || null,
      telefone: body.telefone || null,
      data_ingresso: body.data_ingresso || null,
      observacoes: body.observacoes || null,
    })
    .select()
    .single();
  if (error) return NextResponse.json({ ok: false, erro: error.message }, { status: 400 });
  return NextResponse.json({ ok: true, investidor: data });
}
