"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";
export function LimparDados() {
  const router = useRouter();
  const [txt, setTxt] = useState("");
  const [busy, setBusy] = useState(false);
  const [res, setRes] = useState<any>(null);
  const [erro, setErro] = useState<string | null>(null);
  async function limpar() {
    if (txt !== "APAGAR") { setErro('Digite APAGAR (em maiúsculas) para confirmar.'); return; }
    if (!confirm("Tem certeza? Isso apaga TODOS os investidores, aportes, resgates e comissões. Não dá pra desfazer.")) return;
    setBusy(true); setErro(null); setRes(null);
    const r = await fetch("/api/limpar", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ confirmar: "APAGAR" }) });
    const j = await r.json(); setBusy(false);
    if (!j.ok) return setErro(j.erro);
    setRes(j); setTxt(""); router.refresh();
  }
  const nomes: Record<string, string> = { comissoes: "comissões", resgates: "resgates", aportes: "aportes", investidores: "investidores" };
  return (
    <div className="mt-6 rounded-lg border border-neg/40 bg-neg/5 p-5">
      <div className="eyebrow text-neg">Zona de perigo — limpar dados de teste</div>
      <p className="mt-2 text-sm text-muted">Apaga <b>todos</b> os investidores, aportes, resgates e comissões (mantém empresas, agentes, cautelas e CDI). <b>Não dá pra desfazer.</b></p>
      <div className="mt-3 flex flex-wrap items-center gap-2">
        <input value={txt} onChange={(e) => setTxt(e.target.value)} placeholder='Digite APAGAR' className="rounded-md border bg-paper px-3 py-2 text-sm" />
        <button onClick={limpar} disabled={busy} className="rounded-md bg-neg px-4 py-2 text-sm font-medium text-white disabled:opacity-50">{busy ? "Apagando…" : "Apagar dados de teste"}</button>
      </div>
      {erro && <p className="mt-3 text-sm text-neg">{erro}</p>}
      {res && (
        <div className="mt-3 text-sm">
          {res.tudoZerado
            ? <p className="text-accent">Tudo apagado ✓ — recarregue as telas (F5) se ainda aparecer algo.</p>
            : <p className="text-neg font-medium">Atenção: alguns dados NÃO foram apagados. Veja abaixo (isso indica problema de permissão da chave do Supabase).</p>}
          <table className="mt-2 text-xs">
            <thead><tr className="text-muted"><th className="pr-4 text-left">Tabela</th><th className="pr-4 text-right">Tinha</th><th className="pr-4 text-right">Restou</th><th className="text-left">Erro</th></tr></thead>
            <tbody>
              {Object.entries(res.result).map(([t, v]: any) => (
                <tr key={t}><td className="pr-4">{nomes[t] ?? t}</td><td className="pr-4 text-right">{v.antes}</td><td className={`pr-4 text-right ${v.depois > 0 ? "text-neg font-semibold" : "text-accent"}`}>{v.depois}</td><td className="text-neg">{v.erro || ""}</td></tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
