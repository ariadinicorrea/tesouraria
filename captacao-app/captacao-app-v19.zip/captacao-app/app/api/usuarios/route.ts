import { NextResponse } from "next/server";
import { supabaseAdmin } from "@/lib/supabase/admin";
import { papelAtual } from "@/lib/auth";
export const dynamic = "force-dynamic";

export async function GET() {
  const p = await papelAtual();
  if (!p || p.papel !== "admin") return NextResponse.json({ ok: false, erro: "Acesso restrito." }, { status: 403 });
  const { data } = await supabaseAdmin.from("perfis").select("id, nome, email, papel, created_at").order("created_at");
  return NextResponse.json({ ok: true, usuarios: data });
}
export async function POST(req: Request) {
  const p = await papelAtual();
  if (!p || p.papel !== "admin") return NextResponse.json({ ok: false, erro: "Acesso restrito." }, { status: 403 });
  const b = await req.json();
  if (!b.email || !b.senha || String(b.senha).length < 6) return NextResponse.json({ ok: false, erro: "E-mail e senha (mín. 6) são obrigatórios." }, { status: 400 });
  const papel = ["admin", "gestor", "operador", "leitura"].includes(b.papel) ? b.papel : "leitura";
  const { data: u, error } = await supabaseAdmin.auth.admin.createUser({ email: b.email, password: b.senha, email_confirm: true });
  if (error || !u.user) return NextResponse.json({ ok: false, erro: error?.message || "Falha ao criar." }, { status: 400 });
  const { error: e2 } = await supabaseAdmin.from("perfis").insert({ id: u.user.id, nome: b.nome || null, email: b.email, papel });
  if (e2) return NextResponse.json({ ok: false, erro: e2.message }, { status: 400 });
  return NextResponse.json({ ok: true });
}
