import { supabaseAdmin } from "@/lib/supabase/admin";
import { Card } from "@/components/ui";
import { NovoInvestidor } from "@/components/novo-investidor";
import { fmtData } from "@/lib/format";
import Link from "next/link";
export const dynamic = "force-dynamic";

export default async function InvestidoresPage({ searchParams }: { searchParams: { q?: string } }) {
  const q = (searchParams?.q || "").replace(/[(),]/g, " ").trim();
  let query = supabaseAdmin.from("investidores").select("*").order("created_at", { ascending: false });
  if (q) query = query.or(`nome_razao_social.ilike.%${q}%,documento.ilike.%${q}%`);
  const { data: investidores } = await query;
  return (
    <div className="p-8">
      <header className="flex items-end justify-between">
        <div><div className="eyebrow">Cadastro</div><h1 className="mt-1 text-xl font-semibold tracking-tight">Investidores</h1></div>
        <NovoInvestidor />
      </header>

      <form method="get" className="mt-4 flex flex-wrap items-end gap-2">
        <div><label className="eyebrow">Buscar investidor</label><br/>
          <input name="q" defaultValue={q} placeholder="Nome ou documento" className="w-64 rounded-md border bg-surface px-3 py-2 text-sm" /></div>
        <button type="submit" className="rounded-md bg-ink px-4 py-2 text-sm font-medium text-white">Buscar</button>
        {q && <a href="/investidores" className="rounded-md border px-4 py-2 text-sm hover:bg-paper">Limpar</a>}
      </form>

      <Card className="mt-4">
        <table className="w-full text-sm">
          <thead><tr className="text-left text-xs text-muted">
            <th className="px-5 py-2 font-medium">Nome / Razão social</th>
            <th className="px-5 py-2 font-medium">Documento</th>
            <th className="px-5 py-2 font-medium">Tipo</th>
            <th className="px-5 py-2 font-medium">E-mail</th>
            <th className="px-5 py-2 font-medium">Ingresso</th>
            <th className="px-5 py-2"></th>
          </tr></thead>
          <tbody>
            {(investidores ?? []).map((i) => (
              <tr key={i.id} className="border-t hover:bg-paper">
                <td className="px-5 py-3 font-medium"><Link href={`/investidores/${i.id}`} className="hover:text-accent">{i.nome_razao_social}</Link></td>
                <td className="num px-5 py-3">{i.documento}</td>
                <td className="px-5 py-3 text-muted">{i.tipo_pessoa}</td>
                <td className="px-5 py-3 text-muted">{i.email ?? "—"}</td>
                <td className="num px-5 py-3 text-muted">{fmtData(i.data_ingresso)}</td>
                <td className="px-5 py-3 text-right"><Link href={`/investidores/${i.id}`} className="text-sm text-muted hover:text-ink">Ver posição →</Link></td>
              </tr>
            ))}
            {(!investidores || investidores.length === 0) && (<tr><td colSpan={6} className="px-5 py-6 text-center text-muted">{q ? "Nenhum investidor encontrado para essa busca." : "Nenhum investidor cadastrado."}</td></tr>)}
          </tbody>
        </table>
      </Card>
    </div>
  );
}
