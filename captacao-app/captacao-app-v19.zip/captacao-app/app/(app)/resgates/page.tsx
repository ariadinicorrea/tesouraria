import { computeAportesAtivos } from "@/lib/aporte";
import { supabaseAdmin } from "@/lib/supabase/admin";
import { NovoResgate } from "@/components/novo-resgate";
import { Card } from "@/components/ui";
import { fmtBRL, fmtData } from "@/lib/format";
import Link from "next/link";
export const dynamic = "force-dynamic";

export default async function ResgatesPage({ searchParams }: { searchParams: { investidor?: string } }) {
  const invFiltro = searchParams?.investidor || "";
  const [aportes, investidoresRes] = await Promise.all([
    computeAportesAtivos(),
    supabaseAdmin.from("investidores").select("id, nome_razao_social").order("nome_razao_social"),
  ]);
  let q = supabaseAdmin.from("resgates")
    .select("*, aportes!inner(investidor_id, empresas(nome), investidores(nome_razao_social))")
    .order("data_resgate", { ascending: false }).limit(invFiltro ? 500 : 40);
  if (invFiltro) q = q.eq("aportes.investidor_id", invFiltro);
  const { data: historico } = await q;

  return (
    <div className="p-8">
      <header><div className="eyebrow">Operações</div><h1 className="mt-1 text-xl font-semibold tracking-tight">Resgates</h1></header>
      <div className="mt-6"><NovoResgate aportes={aportes} /></div>
      <Card className="mt-6">
        <div className="flex flex-wrap items-end justify-between gap-3 border-b px-5 py-3">
          <div className="eyebrow">Histórico de resgates</div>
          <form method="get" className="flex items-end gap-2">
            <select name="investidor" defaultValue={invFiltro} className="rounded-md border bg-surface px-3 py-1.5 text-sm">
              <option value="">Todos os investidores</option>
              {(investidoresRes.data ?? []).map((i) => <option key={i.id} value={i.id}>{i.nome_razao_social}</option>)}
            </select>
            <button type="submit" className="rounded-md bg-ink px-3 py-1.5 text-sm font-medium text-white">Filtrar</button>
            {invFiltro && <a href="/resgates" className="rounded-md border px-3 py-1.5 text-sm hover:bg-paper">Limpar</a>}
          </form>
        </div>
        <table className="w-full text-sm">
          <thead><tr className="text-left text-xs text-muted">
            <th className="px-5 py-2 font-medium">Data</th><th className="px-5 py-2 font-medium">Investidor</th>
            <th className="px-5 py-2 font-medium">Tipo</th><th className="px-5 py-2 font-medium">Situação</th>
            <th className="px-5 py-2 text-right font-medium">Bruto</th><th className="px-5 py-2 text-right font-medium">IR</th>
            <th className="px-5 py-2 text-right font-medium">Líquido</th><th className="px-5 py-2"></th>
          </tr></thead>
          <tbody>
            {(historico ?? []).map((r: any) => (
              <tr key={r.id} className="border-t">
                <td className="num px-5 py-3">{fmtData(r.data_resgate)}</td>
                <td className="px-5 py-3">{r.aportes?.investidores?.nome_razao_social ?? "—"}</td>
                <td className="px-5 py-3 text-muted">{r.tipo_resgate}</td>
                <td className="px-5 py-3">{r.status === "efetuado" ? <span className="text-accent">Efetuado</span> : <span className="text-warn">Solicitado</span>}</td>
                <td className="num px-5 py-3 text-right">{fmtBRL(r.valor_bruto)}</td>
                <td className="num px-5 py-3 text-right text-warn">{fmtBRL(r.ir_retido)}</td>
                <td className="num px-5 py-3 text-right font-semibold">{fmtBRL(r.valor_liquido)}</td>
                <td className="px-5 py-3 text-right"><Link href={`/resgates/${r.id}/comprovante`} className="text-xs text-muted hover:text-ink">Comprovante →</Link></td>
              </tr>
            ))}
            {(!historico || historico.length === 0) && (<tr><td colSpan={8} className="px-5 py-6 text-center text-muted">Nenhum resgate encontrado.</td></tr>)}
          </tbody>
        </table>
      </Card>
    </div>
  );
}
