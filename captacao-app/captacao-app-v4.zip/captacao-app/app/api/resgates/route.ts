import { NextResponse } from "next/server";
import { supabaseAdmin } from "@/lib/supabase/admin";
import { computeAporteAtual } from "@/lib/aporte";
import { calcularTributacao } from "@/lib/funding-engine";
export const dynamic = "force-dynamic";

export async function POST(req: Request) {
  const b = await req.json();
  const pos = await computeAporteAtual(b.aporte_id);
  if (!pos) return NextResponse.json({ ok: false, erro: "Aporte não encontrado" }, { status: 404 });
  const tipo = b.tipo_resgate as "parcial" | "total" | "apenas_juros";

  let valorBruto = 0; let baseIR = 0;
  if (tipo === "total") { valorBruto = pos.saldoBruto; baseIR = pos.rendimento; }
  else if (tipo === "apenas_juros") { valorBruto = pos.rendimento; baseIR = pos.rendimento; }
  else {
    const principal = Number(b.valor_principal) || 0;
    const juros = Number(b.valor_juros) || 0;
    if (principal + juros <= 0) return NextResponse.json({ ok: false, erro: "Informe o valor de principal e/ou juros a resgatar" }, { status: 400 });
    if (juros > pos.rendimento + 0.01) return NextResponse.json({ ok: false, erro: `Juros solicitado maior que o rendimento disponível (${pos.rendimento.toFixed(2)})` }, { status: 400 });
    if (principal + juros > pos.saldoBruto + 0.01) return NextResponse.json({ ok: false, erro: "Total maior que o saldo disponível" }, { status: 400 });
    valorBruto = principal + juros; baseIR = juros; // IR só sobre os juros
  }
  const trib = calcularTributacao(pos.regime, baseIR, pos.diasCorridos);
  const valorLiquido = valorBruto - trib.irRetido;

  const { error } = await supabaseAdmin.from("resgates").insert({
    aporte_id: b.aporte_id, data_resgate: b.data_resgate || new Date().toISOString().slice(0, 10),
    tipo_resgate: tipo, valor_solicitado: tipo === "parcial" ? valorBruto : null,
    valor_bruto: valorBruto, base_calculo_ir: baseIR, aliquota_ir: trib.aliquota,
    ir_retido: trib.irRetido, valor_liquido: valorLiquido, prazo_dias: pos.diasCorridos,
  });
  if (error) return NextResponse.json({ ok: false, erro: error.message }, { status: 400 });
  if (tipo === "total") await supabaseAdmin.from("aportes").update({ status: "resgatado_total" }).eq("id", b.aporte_id);
  return NextResponse.json({ ok: true, valorBruto, irRetido: trib.irRetido, aliquota: trib.aliquota, valorLiquido });
}
