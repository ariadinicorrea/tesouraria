import { computeComissoes } from "@/lib/comissoes";
import { supabaseAdmin } from "@/lib/supabase/admin";
import { Card, Stat } from "@/components/ui";
import { PrintButton } from "@/components/print-button";
import { fmtBRL, fmtPct, fmtData } from "@/lib/format";
export const dynamic = "force-dynamic";

export default async function ComissoesPage({ searchParams }: { searchParams: { agente?: string; de?: string; ate?: string } }) {
  const { data: agentes } = await supabaseAdmin.from("agentes").select("id, nome").order("nome");
  const { porAgente, totalGeral } = await computeComissoes({ agenteId: searchParams?.agente || undefined, de: searchParams?.de || undefined, ate: searchParams?.ate || undefined });
  return (
    <div className="p-8">
      <header className="flex flex-wrap items-end justify-between gap-3">
        <div><div className="eyebrow">Financeiro</div><h1 className="mt-1 text-xl font-semibold tracking-tight">Comissões de captação</h1></div>
        <PrintButton />
      </header>

      <form method="get" className="mt-4 flex flex-wrap items-end gap-3 no-print">
        <div><label className="eyebrow">Agente</label><br/>
          <select name="agente" defaultValue={searchParams?.agente ?? ""} className="rounded-md border bg-surface px-3 py-2 text-sm">
            <option value="">Todos</option>{(agentes ?? []).map((a) => <option key={a.id} value={a.id}>{a.nome}</option>)}
          </select>
        </div>
        <div><label className="eyebrow">De</label><br/><input type="date" name="de" defaultValue={searchParams?.de ?? ""} className="rounded-md border bg-surface px-3 py-2 text-sm" /></div>
        <div><label className="eyebrow">Até</label><br/><input type="date" name="ate" defaultValue={searchParams?.ate ?? ""} className="rounded-md border bg-surface px-3 py-2 text-sm" /></div>
        <button type="submit" className="rounded-md bg-ink px-4 py-2 text-sm font-medium text-white">Filtrar</button>
      </form>

      <div className="mt-6 grid grid-cols-2 gap-4 md:grid-cols-4">
        <Stat label="Total de comissões" value={fmtBRL(totalGeral)} tone="warn" />
        <Stat label="Agentes" value={String(porAgente.length)} />
      </div>

      {porAgente.length === 0 && <Card className="mt-6 p-6"><p className="text-sm text-muted">Nenhuma comissão no filtro selecionado.</p></Card>}
      {porAgente.map((g) => (
        <Card key={g.agenteId} className="mt-6">
          <div className="flex items-center justify-between border-b px-5 py-3"><div className="eyebrow">{g.agente}</div><div className="num text-sm font-semibold text-warn">{fmtBRL(g.total)}</div></div>
          <table className="w-full text-sm">
            <thead><tr className="text-left text-xs text-muted">
              <th className="px-5 py-2 font-medium">Data</th><th className="px-5 py-2 font-medium">Investidor</th><th className="px-5 py-2 font-medium">Empresa</th>
              <th className="px-5 py-2 text-right font-medium">Aporte</th><th className="px-5 py-2 text-right font-medium">%</th><th className="px-5 py-2 text-right font-medium">Comissão</th>
            </tr></thead>
            <tbody>
              {g.itens.map((it) => (
                <tr key={it.aporteId} className="border-t">
                  <td className="num px-5 py-3">{fmtData(it.dataAporte)}</td><td className="px-5 py-3">{it.investidor}</td><td className="px-5 py-3 text-muted">{it.empresa}</td>
                  <td className="num px-5 py-3 text-right">{fmtBRL(it.valorAporte)}</td><td className="num px-5 py-3 text-right">{fmtPct(it.pct)}</td><td className="num px-5 py-3 text-right text-warn">{fmtBRL(it.comissao)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </Card>
      ))}
    </div>
  );
}
