import { supabaseAdmin } from "@/lib/supabase/admin";

export interface ItemTributo { data: string; empresa: string; tipo: string; valorBruto: number; iof: number; ir: number; aliquotaIr: number; }
export interface InvestidorTributo { investidor: string; documento: string; totalIr: number; totalIof: number; itens: ItemTributo[]; }

export async function computeTributos(ano?: number): Promise<{ porInvestidor: InvestidorTributo[]; totalIr: number; totalIof: number; ano: number }> {
  const a = ano ?? new Date().getFullYear() - 1;
  const { data } = await supabaseAdmin.from("resgates")
    .select(`data_resgate, valor_bruto, ir_retido, iof_retido, aliquota_ir, status,
      aportes!inner(empresas(nome), investidores(nome_razao_social, documento))`)
    .eq("status", "efetuado")
    .gte("data_resgate", `${a}-01-01`).lte("data_resgate", `${a}-12-31`)
    .order("data_resgate", { ascending: true });

  const mapa = new Map<string, InvestidorTributo>();
  let totalIr = 0, totalIof = 0;
  for (const r of (data ?? []) as any[]) {
    const inv = r.aportes?.investidores;
    const chave = inv?.documento ?? inv?.nome_razao_social ?? "—";
    const ir = Number(r.ir_retido), iof = Number(r.iof_retido ?? 0);
    totalIr += ir; totalIof += iof;
    if (!mapa.has(chave)) mapa.set(chave, { investidor: inv?.nome_razao_social ?? "—", documento: inv?.documento ?? "—", totalIr: 0, totalIof: 0, itens: [] });
    const g = mapa.get(chave)!;
    g.totalIr += ir; g.totalIof += iof;
    g.itens.push({ data: r.data_resgate, empresa: r.aportes?.empresas?.nome ?? "—", tipo: "Resgate", valorBruto: Number(r.valor_bruto), iof, ir, aliquotaIr: Number(r.aliquota_ir) });
  }
  return { porInvestidor: Array.from(mapa.values()).sort((x, y) => y.totalIr - x.totalIr), totalIr, totalIof, ano: a };
}
