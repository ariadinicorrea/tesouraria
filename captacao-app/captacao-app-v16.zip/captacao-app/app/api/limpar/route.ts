import { NextResponse } from "next/server";
import { supabaseAdmin } from "@/lib/supabase/admin";
export const dynamic = "force-dynamic";
const Z = "00000000-0000-0000-0000-000000000000";
export async function POST(req: Request) {
  const b = await req.json();
  if (b.confirmar !== "APAGAR") return NextResponse.json({ ok: false, erro: 'Digite APAGAR para confirmar.' }, { status: 400 });
  const tabelas = ["comissoes", "resgates", "aportes", "investidores"];
  const apagados: Record<string, number> = {};
  for (const t of tabelas) {
    const { count } = await supabaseAdmin.from(t).select("id", { count: "exact", head: true });
    const { error } = await supabaseAdmin.from(t).delete().neq("id", Z);
    if (error) return NextResponse.json({ ok: false, erro: `Erro ao limpar ${t}: ${error.message}` }, { status: 400 });
    apagados[t] = count ?? 0;
  }
  return NextResponse.json({ ok: true, apagados });
}
