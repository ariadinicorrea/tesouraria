"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";
export function LimparDados() {
  const router = useRouter();
  const [txt, setTxt] = useState("");
  const [busy, setBusy] = useState(false);
  const [res, setRes] = useState<any>(null);
  const [erro, setErro] = useState<string | null>(null);
  async function limpar() {
    if (txt !== "APAGAR") { setErro('Digite APAGAR (em maiúsculas) para confirmar.'); return; }
    if (!confirm("Tem certeza? Isso apaga TODOS os investidores, aportes, resgates e comissões. Não dá pra desfazer.")) return;
    setBusy(true); setErro(null); setRes(null);
    const r = await fetch("/api/limpar", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ confirmar: "APAGAR" }) });
    const j = await r.json(); setBusy(false);
    if (!j.ok) return setErro(j.erro);
    setRes(j.apagados); setTxt(""); router.refresh();
  }
  return (
    <div className="mt-6 rounded-lg border border-neg/40 bg-neg/5 p-5">
      <div className="eyebrow text-neg">Zona de perigo — limpar dados de teste</div>
      <p className="mt-2 text-sm text-muted">Apaga <b>todos</b> os investidores, aportes, resgates e comissões (mantém empresas, agentes, cautelas e o CDI). Use antes de importar sua base real. <b>Não dá pra desfazer.</b></p>
      <div className="mt-3 flex flex-wrap items-center gap-2">
        <input value={txt} onChange={(e) => setTxt(e.target.value)} placeholder='Digite APAGAR' className="rounded-md border bg-paper px-3 py-2 text-sm" />
        <button onClick={limpar} disabled={busy} className="rounded-md bg-neg px-4 py-2 text-sm font-medium text-white disabled:opacity-50">{busy ? "Apagando…" : "Apagar dados de teste"}</button>
      </div>
      {erro && <p className="mt-3 text-sm text-neg">{erro}</p>}
      {res && <p className="mt-3 text-sm text-accent">Pronto! Apagados — investidores: {res.investidores}, aportes: {res.aportes}, resgates: {res.resgates}, comissões: {res.comissoes}.</p>}
    </div>
  );
}
