import { supabaseAdmin } from "@/lib/supabase/admin";
import { Card } from "@/components/ui";
import { NovoAporte } from "@/components/novo-aporte";
import { Tabela, type Coluna } from "@/components/tabela";
export const dynamic = "force-dynamic";

export default async function AportesPage({ searchParams }: { searchParams: { investidor?: string } }) {
  const invFiltro = searchParams?.investidor || "";
  let aportesQ = supabaseAdmin.from("aportes").select("*, empresas(nome), investidores(nome_razao_social)").order("data_aporte", { ascending: false });
  if (invFiltro) aportesQ = aportesQ.eq("investidor_id", invFiltro);

  const [empresasRes, investidoresRes, instrumentosRes, agentesRes, aportesRes, cautelasRes] = await Promise.all([
    supabaseAdmin.from("empresas").select("id, nome").eq("ativo", true).order("nome"),
    supabaseAdmin.from("investidores").select("id, nome_razao_social").order("nome_razao_social"),
    supabaseAdmin.from("instrumentos_financeiros").select("id, nome, baseado_em_cotas").order("nome"),
    supabaseAdmin.from("agentes").select("id, nome, comissao_padrao").eq("ativo", true).order("nome"),
    aportesQ,
    supabaseAdmin.from("cautelas").select("id, empresa_id, serie").eq("ativo", true).order("serie"),
  ]);

  const linhas = (aportesRes.data ?? []).map((a: any) => ({
    id: a.id, data_aporte: a.data_aporte, empresa_nome: a.empresas?.nome ?? "—",
    investidor_nome: a.investidores?.nome_razao_social ?? "—", valor_aporte: Number(a.valor_aporte),
    tipo_remuneracao: a.tipo_remuneracao,
  }));
  const colunas: Coluna[] = [
    { chave: "data_aporte", rotulo: "Data", tipo: "data" },
    { chave: "empresa_nome", rotulo: "Empresa" },
    { chave: "investidor_nome", rotulo: "Investidor" },
    { chave: "valor_aporte", rotulo: "Valor", tipo: "moeda", align: "right" },
    { chave: "tipo_remuneracao", rotulo: "Modalidade" },
    { chave: "acoes", rotulo: "", links: [{ rotulo: "Editar", base: "/aportes/", sufixo: "/editar" }, { rotulo: "Conta corrente →", base: "/aportes/" }] },
  ];
  return (
    <div className="p-8">
      <header><div className="eyebrow">Operações</div><h1 className="mt-1 text-xl font-semibold tracking-tight">Aportes</h1></header>
      <div className="mt-6"><NovoAporte empresas={empresasRes.data ?? []} investidores={investidoresRes.data ?? []} instrumentos={instrumentosRes.data ?? []} agentes={(agentesRes.data ?? []) as any} cautelas={(cautelasRes.data ?? []) as any} /></div>
      <Card className="mt-6">
        <div className="flex flex-wrap items-end justify-between gap-3 border-b px-5 py-3">
          <div className="eyebrow">{invFiltro ? "Aportes do investidor" : "Aportes"}</div>
          <form method="get" className="flex items-end gap-2">
            <select name="investidor" defaultValue={invFiltro} className="rounded-md border bg-surface px-3 py-1.5 text-sm">
              <option value="">Todos os investidores</option>
              {(investidoresRes.data ?? []).map((i) => <option key={i.id} value={i.id}>{i.nome_razao_social}</option>)}
            </select>
            <button type="submit" className="rounded-md bg-ink px-3 py-1.5 text-sm font-medium text-white">Filtrar</button>
            {invFiltro && <a href="/aportes" className="rounded-md border px-3 py-1.5 text-sm hover:bg-paper">Limpar</a>}
          </form>
        </div>
        <Tabela colunas={colunas} linhas={linhas} vazio="Nenhum aporte encontrado." />
      </Card>
    </div>
  );
}
