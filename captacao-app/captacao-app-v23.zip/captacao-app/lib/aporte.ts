import { supabaseAdmin } from "@/lib/supabase/admin";
import {
  taxaEfetivaAnual, saldoBrutoAtualizado, contarDiasUteis,
  posicaoCotasFIDC, type ParametrosRemuneracao, type RegimeTributario,
} from "@/lib/funding-engine";

export interface AporteAtual {
  aporteId: string; empresa: string; investidor: string;
  valorAportado: number; dataAporte: string; saldoBruto: number;
  rendimento: number; regime: RegimeTributario; diasCorridos: number; taxaEf: number;
}

async function cdiVigente(): Promise<number> {
  const { data } = await supabaseAdmin.from("cdi_historico").select("taxa_anual").order("data_referencia", { ascending: false }).limit(1).maybeSingle();
  return data ? Number(data.taxa_anual) : 0;
}
async function valorCotaAtual(empresaId: string): Promise<number | null> {
  const { data } = await supabaseAdmin.from("cotas_valor_historico").select("valor_cota").eq("empresa_id", empresaId).order("data_referencia", { ascending: false }).limit(1).maybeSingle();
  return data ? Number(data.valor_cota) : null;
}
async function resgatesEfetuados(aporteId: string): Promise<{ bruto: number; principal: number }> {
  const { data } = await supabaseAdmin.from("resgates")
    .select("valor_bruto, base_calculo_ir, status").eq("aporte_id", aporteId).eq("status", "efetuado");
  let bruto = 0, principal = 0;
  for (const r of data ?? []) { const vb = Number(r.valor_bruto); bruto += vb; principal += vb - Number(r.base_calculo_ir); }
  return { bruto, principal };
}

async function calcular(a: any, cdi: number): Promise<AporteAtual> {
  const emp = Array.isArray(a.empresas) ? a.empresas[0] : a.empresas;
  const instr = Array.isArray(a.instrumentos_financeiros) ? a.instrumentos_financeiros[0] : a.instrumentos_financeiros;
  const inv = Array.isArray(a.investidores) ? a.investidores[0] : a.investidores;
  const params: ParametrosRemuneracao = {
    tipo: a.tipo_remuneracao, taxaValor: a.taxa_valor ?? undefined,
    periodo: a.periodo_taxa ?? undefined, percentualCdi: a.percentual_cdi ?? undefined,
  };
  const taxaEf = taxaEfetivaAnual(params, cdi);
  const dataAporte = new Date(a.data_aporte);
  const hoje = new Date();
  const diasUteis = contarDiasUteis(dataAporte, hoje);
  const diasCorridos = Math.floor((hoje.getTime() - dataAporte.getTime()) / 86400000);
  const cotaAtual = instr?.baseado_em_cotas ? await valorCotaAtual(a.empresa_id) : null;
  let saldoBruto: number; let rendimento: number;
  if (cotaAtual && a.quantidade_cotas && a.valor_cota_aporte) {
    const p = posicaoCotasFIDC(a.quantidade_cotas, a.valor_cota_aporte, cotaAtual);
    saldoBruto = p.patrimonioBruto; rendimento = p.rendimentoBruto;
  } else {
    saldoBruto = saldoBrutoAtualizado(a.valor_aporte, taxaEf, diasUteis);
    rendimento = saldoBruto - a.valor_aporte;
  }
  const res = await resgatesEfetuados(a.id);
  const principalVigente = a.valor_aporte - res.principal;
  saldoBruto -= res.bruto; if (saldoBruto < 0) saldoBruto = 0;
  rendimento = saldoBruto - principalVigente; if (rendimento < 0) rendimento = 0;
  const regime: RegimeTributario =
    instr?.isento_ir || emp?.tipo === "contratos" ? "isento" : (emp?.regime_tributario as RegimeTributario);
  return {
    aporteId: a.id, empresa: emp?.nome, investidor: inv?.nome_razao_social,
    valorAportado: a.valor_aporte, dataAporte: a.data_aporte, saldoBruto, rendimento, regime, diasCorridos, taxaEf,
  };
}

export async function computeAportesAtivos(): Promise<AporteAtual[]> {
  const cdi = await cdiVigente();
  const { data } = await supabaseAdmin.from("aportes")
    .select(`*, empresas!inner(nome, tipo, regime_tributario), investidores!inner(nome_razao_social), instrumentos_financeiros!inner(baseado_em_cotas, isento_ir)`)
    .eq("status", "ativo").order("data_aporte", { ascending: false });
  const out: AporteAtual[] = [];
  for (const a of data ?? []) out.push(await calcular(a, cdi));
  return out;
}

export async function computeAporteAtual(aporteId: string): Promise<AporteAtual | null> {
  const cdi = await cdiVigente();
  const { data } = await supabaseAdmin.from("aportes")
    .select(`*, empresas!inner(nome, tipo, regime_tributario), investidores!inner(nome_razao_social), instrumentos_financeiros!inner(baseado_em_cotas, isento_ir)`)
    .eq("id", aporteId).maybeSingle();
  if (!data) return null;
  return calcular(data, cdi);
}

export interface Movimento { data: string; descricao: string; entrada: number; saida: number; saldo: number; }
export interface ContaCorrente {
  aporte: any; investidor: string; empresa: string; instrumento: string;
  agente: string | null; comissaoValor: number; comissaoPct: number;
  movimentos: Movimento[]; saldoCaixa: number; posicao: AporteAtual | null;
}

export async function computeContaCorrente(aporteId: string): Promise<ContaCorrente | null> {
  const { data: a } = await supabaseAdmin.from("aportes")
    .select(`*, empresas(nome), investidores(nome_razao_social), instrumentos_financeiros(nome), agentes(nome, comissao_padrao)`)
    .eq("id", aporteId).maybeSingle();
  if (!a) return null;

  const { data: resgates } = await supabaseAdmin.from("resgates")
    .select("*").eq("aporte_id", aporteId).order("data_resgate", { ascending: true });

  const eventos: { data: string; descricao: string; entrada: number; saida: number }[] = [
    { data: a.data_aporte, descricao: "Aporte", entrada: Number(a.valor_aporte), saida: 0 },
  ];
  for (const r of resgates ?? []) {
    const rotulo = r.tipo_resgate === "total" ? "Resgate total" : r.tipo_resgate === "apenas_juros" ? "Resgate de juros" : "Resgate parcial";
    eventos.push({ data: r.data_resgate, descricao: `${rotulo} (IR ${fmtPctSimples(Number(r.aliquota_ir))})`, entrada: 0, saida: Number(r.valor_bruto) });
  }
  eventos.sort((x, y) => x.data.localeCompare(y.data));

  let saldo = 0;
  const movimentos: Movimento[] = eventos.map((e) => { saldo += e.entrada - e.saida; return { ...e, saldo }; });

  const comissaoPct = a.comissao_percentual != null ? Number(a.comissao_percentual) : Number(a.agentes?.comissao_padrao ?? 0);
  const comissaoValor = Number(a.valor_aporte) * comissaoPct;

  const posicao = await computeAporteAtual(aporteId);

  return {
    aporte: a, investidor: a.investidores?.nome_razao_social, empresa: a.empresas?.nome,
    instrumento: a.instrumentos_financeiros?.nome, agente: a.agentes?.nome ?? null,
    comissaoValor, comissaoPct, movimentos, saldoCaixa: saldo, posicao,
  };
}
function fmtPctSimples(f: number) { return `${(f * 100).toFixed(1)}%`; }

export async function computeResgateDetalhe(resgateId: string) {
  const { data: r } = await supabaseAdmin.from("resgates")
    .select(`*, aportes!inner(valor_aporte, empresas(nome), investidores(nome_razao_social, documento, email, telefone))`)
    .eq("id", resgateId).maybeSingle();
  if (!r) return null;
  const inv = (r as any).aportes?.investidores;
  return {
    resgate: r,
    empresa: (r as any).aportes?.empresas?.nome ?? "",
    investidor: inv?.nome_razao_social ?? "",
    documento: inv?.documento ?? "",
    email: inv?.email ?? "",
    telefone: inv?.telefone ?? "",
  };
}
