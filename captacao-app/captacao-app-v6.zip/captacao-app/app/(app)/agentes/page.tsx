import { supabaseAdmin } from "@/lib/supabase/admin";
import { Card } from "@/components/ui";
import { NovoAgente } from "@/components/novo-agente";
import { fmtPct } from "@/lib/format";
export const dynamic = "force-dynamic";
export default async function AgentesPage() {
  const { data: agentes } = await supabaseAdmin.from("agentes").select("*").order("nome");
  return (
    <div className="p-8">
      <header className="flex items-end justify-between">
        <div><div className="eyebrow">Cadastro</div><h1 className="mt-1 text-xl font-semibold tracking-tight">Agentes captadores</h1></div>
        <NovoAgente />
      </header>
      <Card className="mt-6">
        <table className="w-full text-sm">
          <thead><tr className="text-left text-xs text-muted">
            <th className="px-5 py-2 font-medium">Nome</th><th className="px-5 py-2 font-medium">Documento</th>
            <th className="px-5 py-2 font-medium">E-mail</th><th className="px-5 py-2 text-right font-medium">Comissão padrão</th>
          </tr></thead>
          <tbody>
            {(agentes ?? []).map((a) => (
              <tr key={a.id} className="border-t">
                <td className="px-5 py-3 font-medium">{a.nome}</td>
                <td className="num px-5 py-3">{a.documento ?? "—"}</td>
                <td className="px-5 py-3 text-muted">{a.email ?? "—"}</td>
                <td className="num px-5 py-3 text-right text-accent">{fmtPct(Number(a.comissao_padrao))}</td>
              </tr>
            ))}
            {(!agentes || agentes.length === 0) && (<tr><td colSpan={4} className="px-5 py-6 text-center text-muted">Nenhum agente cadastrado.</td></tr>)}
          </tbody>
        </table>
      </Card>
    </div>
  );
}
