import { supabaseAdmin } from "@/lib/supabase/admin";
import { Card } from "@/components/ui";
import { NovoAporte } from "@/components/novo-aporte";
import { fmtBRL, fmtData } from "@/lib/format";
import Link from "next/link";
export const dynamic = "force-dynamic";
export default async function AportesPage() {
  const [empresasRes, investidoresRes, instrumentosRes, agentesRes, aportesRes, cautelasRes] = await Promise.all([
    supabaseAdmin.from("empresas").select("id, nome").eq("ativo", true).order("nome"),
    supabaseAdmin.from("investidores").select("id, nome_razao_social").order("nome_razao_social"),
    supabaseAdmin.from("instrumentos_financeiros").select("id, nome, baseado_em_cotas").order("nome"),
    supabaseAdmin.from("agentes").select("id, nome, comissao_padrao").eq("ativo", true).order("nome"),
    supabaseAdmin.from("aportes").select("*, empresas(nome), investidores(nome_razao_social)").order("data_aporte", { ascending: false }).limit(30),
    supabaseAdmin.from("cautelas").select("id, empresa_id, serie").eq("ativo", true).order("serie"),
  ]);
  return (
    <div className="p-8">
      <header><div className="eyebrow">Operações</div><h1 className="mt-1 text-xl font-semibold tracking-tight">Aportes</h1></header>
      <div className="mt-6"><NovoAporte empresas={empresasRes.data ?? []} investidores={investidoresRes.data ?? []} instrumentos={instrumentosRes.data ?? []} agentes={(agentesRes.data ?? []) as any} cautelas={(cautelasRes.data ?? []) as any} /></div>
      <Card className="mt-6">
        <div className="border-b px-5 py-3 eyebrow">Últimos aportes</div>
        <table className="w-full text-sm">
          <thead><tr className="text-left text-xs text-muted">
            <th className="px-5 py-2 font-medium">Data</th><th className="px-5 py-2 font-medium">Empresa</th>
            <th className="px-5 py-2 font-medium">Investidor</th><th className="px-5 py-2 text-right font-medium">Valor</th>
            <th className="px-5 py-2 font-medium">Modalidade</th><th className="px-5 py-2"></th>
          </tr></thead>
          <tbody>
            {(aportesRes.data ?? []).map((a: any) => (
              <tr key={a.id} className="border-t">
                <td className="num px-5 py-3">{fmtData(a.data_aporte)}</td>
                <td className="px-5 py-3">{a.empresas?.nome}</td>
                <td className="px-5 py-3">{a.investidores?.nome_razao_social}</td>
                <td className="num px-5 py-3 text-right">{fmtBRL(a.valor_aporte)}</td>
                <td className="px-5 py-3 text-muted">{a.tipo_remuneracao}</td>
                <td className="px-5 py-3 text-right"><Link href={`/aportes/${a.id}`} className="text-sm text-muted hover:text-ink">Conta corrente →</Link></td>
              </tr>
            ))}
            {(!aportesRes.data || aportesRes.data.length === 0) && (<tr><td colSpan={6} className="px-5 py-6 text-center text-muted">Nenhum aporte ainda.</td></tr>)}
          </tbody>
        </table>
      </Card>
    </div>
  );
}
